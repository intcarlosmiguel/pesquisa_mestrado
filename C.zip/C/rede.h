#ifndef REDE_H
#define REDE_H

struct Graph;
void result(struct Graph G,double* resultados);
void create_network(struct Graph G,double p);

#endif
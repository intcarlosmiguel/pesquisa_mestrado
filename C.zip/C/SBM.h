#ifndef SBM_H
#define SBM_H

struct Graph;
void generate_SBM_p_model(int T,int model,double p);

#endif
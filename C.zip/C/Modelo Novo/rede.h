#ifndef REDE_H
#define REDE_H


/* 
double global_clustering(int** viz,int N);
double avarage_clustering(int** viz,int N);
double* list_clustering(int** viz,int N);
double shortest_length(int** viz,int N,int site,double* diametro);
double av_path_length(int** viz,int N,double* diametro);
double* degree_list(int** viz,int N);
void degree_distribution(struct Graph G,double* media1,double* median1,double* std1);
//double* result(struct Graph G,double p); */
#endif
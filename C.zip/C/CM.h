#ifndef CM_H
#define CM_H

struct Graph;

void generate_configuration_model(double p, int T);

#endif
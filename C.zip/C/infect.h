#ifndef INFECT_H
#define INFECT_H
struct Graph;

void generate_infect(int seed, int redes,double f);


#endif